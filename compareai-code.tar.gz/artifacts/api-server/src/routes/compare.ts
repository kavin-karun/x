import { Router, type IRouter } from "express";
import Anthropic from "@anthropic-ai/sdk";
import { CompareBody } from "@workspace/api-zod";

const router: IRouter = Router();

function getAnthropicClient(): Anthropic {
  if (
    process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL &&
    process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY
  ) {
    return new Anthropic({
      apiKey: process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY,
      baseURL: process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL,
    });
  }
  if (!process.env.ANTHROPIC_API_KEY) {
    throw new Error(
      "ANTHROPIC_API_KEY must be set. Please add it in your Replit Secrets.",
    );
  }
  return new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
}

router.post("/compare", async (req, res): Promise<void> => {
  const parsed = CompareBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { items, mode } = parsed.data;
  const isSideBySide = mode === "side-by-side";
  const itemsList = items.map((item, i) => `${i + 1}. ${item}`).join("\n");

  const systemPrompt = `You are CompareAI — an expert comparison assistant. Give users smart, structured, decisive comparisons. Be confident, direct, and helpful. Never hedgy. Never robotic. Always give a clear winner.

Auto-detect the comparison type (tech, fitness, food, lifestyle, academic, career, etc.) and pick the most relevant categories for that domain.

Detect whether the user seems like a beginner or expert from their phrasing and adjust depth accordingly.

Be neutral and fact-based. Separate facts from opinions. Use real-world examples where helpful. If input is vague or misspelled, infer intent and proceed confidently.`;

  const tableHeader = `| Category | ${items.join(" | ")} |`;
  const tableSeparator = `|----------|${items.map(() => "------").join(" | ")} |`;

  const prosConsSection = items
    .map(
      (item) =>
        `### ${item}\n**Pros:**\n- [3-4 key pros]\n\n**Cons:**\n- [2-3 key cons]`,
    )
    .join("\n\n");

  const userPrompt = `Compare these items${isSideBySide ? " in a detailed side-by-side format" : ""}:
${itemsList}

Format your response EXACTLY like this (use markdown):

**[One sentence framing the comparison and what's at stake]**

## ${isSideBySide ? "Side-by-Side" : "Quick"} Comparison

${tableHeader}
${tableSeparator}
[Fill in ${isSideBySide ? "6-8" : "5-6"} auto-detected relevant category rows]

## Pros & Cons

${prosConsSection}

## Category Winners

[For each category in the table, declare a winner with 1-sentence reasoning]

## 🏆 Overall Winner: [NAME]

[2-3 sentence decisive recommendation. Be direct and confident. Who should pick which option and why?]

## You might also want to compare...
[Suggest 2-3 related comparison ideas]`;

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");

  try {
    const client = getAnthropicClient();
    const stream = client.messages.stream({
      model: "claude-sonnet-4-6",
      max_tokens: 8192,
      system: systemPrompt,
      messages: [{ role: "user", content: userPrompt }],
    });

    for await (const event of stream) {
      if (
        event.type === "content_block_delta" &&
        event.delta.type === "text_delta"
      ) {
        res.write(`data: ${JSON.stringify({ content: event.delta.text })}\n\n`);
      }
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    req.log.error({ err }, "Error calling Anthropic API");
    if (!res.headersSent) {
      res.status(500).json({ error: "Something went wrong — please try again" });
      return;
    }
    res.write(
      `data: ${JSON.stringify({ error: "Something went wrong — please try again" })}\n\n`,
    );
    res.end();
  }
});

export default router;
