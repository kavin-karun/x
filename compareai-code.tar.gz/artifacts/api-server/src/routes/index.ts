import { Router, type IRouter } from "express";
import healthRouter from "./health";
import compareRouter from "./compare";

const router: IRouter = Router();

router.use(healthRouter);
router.use(compareRouter);

export default router;
