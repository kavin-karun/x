import React, { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { MarkdownRenderer } from "@/components/markdown-renderer";
import { ArrowRightLeft, Plus, X, AlignLeft, LayoutPanelLeft, Clock, Trash2, Menu } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useIsMobile } from "@/hooks/use-mobile";

interface HistoryItem {
  id: string;
  items: string[];
  mode: "standard" | "side-by-side";
  timestamp: number;
}

export default function Home() {
  const [items, setItems] = useState<string[]>(["", ""]);
  const [mode, setMode] = useState<"standard" | "side-by-side">("standard");
  const [result, setResult] = useState<string>("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const isMobile = useIsMobile();

  // Load history & apply dark mode
  useEffect(() => {
    document.documentElement.classList.add("dark");
    try {
      const stored = localStorage.getItem("compareai-history");
      if (stored) setHistory(JSON.parse(stored));
    } catch (e) {}
  }, []);

  const saveHistory = (newItems: string[], newMode: "standard" | "side-by-side") => {
    const validItems = newItems.filter(i => i.trim());
    if (validItems.length < 2) return;
    
    const newItem: HistoryItem = {
      id: Math.random().toString(36).substring(7),
      items: validItems,
      mode: newMode,
      timestamp: Date.now()
    };
    
    setHistory(prev => {
      const next = [newItem, ...prev].slice(0, 10);
      localStorage.setItem("compareai-history", JSON.stringify(next));
      return next;
    });
  };

  const handleCompare = async (triggerMode: "standard" | "side-by-side" = "standard", providedItems: string[] = items) => {
    const validItems = providedItems.filter(i => i.trim());
    if (validItems.length < 2) return;

    setMode(triggerMode);
    setResult("");
    setError(null);
    setIsStreaming(true);
    saveHistory(validItems, triggerMode);

    try {
      const response = await fetch("/api/compare", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items: validItems, mode: triggerMode }),
      });
      
      if (!response.ok) throw new Error("Failed to fetch");

      const reader = response.body!.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
        
        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const json = JSON.parse(line.slice(6));
              if (json.content) setResult(prev => prev + json.content);
              if (json.done) setIsStreaming(false);
              if (json.error) setError(json.error);
            } catch (e) {
              console.error("Error parsing SSE JSON", e);
            }
          }
        }
      }
    } catch (err) {
      setError("Something went wrong — please try again");
      setIsStreaming(false);
    }
  };

  const swapItems = () => {
    if (items.length >= 2) {
      const newItems = [...items];
      const temp = newItems[0];
      newItems[0] = newItems[1];
      newItems[1] = temp;
      setItems(newItems);
    }
  };

  const addItem = () => {
    if (items.length < 3) setItems([...items, ""]);
  };

  const removeItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const handleItemChange = (index: number, value: string) => {
    const newItems = [...items];
    newItems[index] = value;
    setItems(newItems);
  };

  const applySuggestion = (suggestion: string) => {
    const [a, b] = suggestion.split(" vs ");
    const newItems = [a, b];
    setItems(newItems);
  };

  const loadHistoryItem = (item: HistoryItem) => {
    setItems(item.items.length === 2 ? [item.items[0], item.items[1]] : item.items);
    handleCompare(item.mode, item.items);
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem("compareai-history");
  };

  const canCompare = items.filter(i => i.trim()).length >= 2;

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b border-border">
        <h2 className="font-semibold text-foreground flex items-center gap-2">
          <Clock className="w-4 h-4 text-muted-foreground" />
          History
        </h2>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-3 space-y-2">
          {history.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">No history yet</p>
          ) : (
            history.map((item) => (
              <button
                key={item.id}
                onClick={() => loadHistoryItem(item)}
                className="w-full text-left p-3 rounded-md hover:bg-muted transition-colors text-sm group"
              >
                <div className="font-medium text-foreground truncate">
                  {item.items.join(" vs ")}
                </div>
                <div className="text-xs text-muted-foreground mt-1 flex justify-between">
                  <span>{item.mode === "standard" ? "Standard" : "Side-by-side"}</span>
                  <span>{new Date(item.timestamp).toLocaleDateString()}</span>
                </div>
              </button>
            ))
          )}
        </div>
      </ScrollArea>
      {history.length > 0 && (
        <div className="p-4 border-t border-border mt-auto">
          <Button variant="ghost" className="w-full text-muted-foreground hover:text-destructive" onClick={clearHistory}>
            <Trash2 className="w-4 h-4 mr-2" />
            Clear History
          </Button>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-background text-foreground flex">
      {/* Sidebar - Desktop */}
      {!isMobile && (
        <aside className="w-64 border-r border-border bg-card flex-shrink-0 fixed h-screen top-0 left-0">
          <SidebarContent />
        </aside>
      )}

      {/* Main Content */}
      <main className={`flex-1 flex flex-col ${!isMobile ? 'ml-64' : ''}`}>
        {/* Header */}
        <header className="px-6 py-8 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-10">
          <div className="max-w-3xl mx-auto flex items-start justify-between">
            <div>
              <h1 className="text-3xl font-bold tracking-tight text-foreground">CompareAI</h1>
              <p className="text-muted-foreground mt-1">Compare anything. Decide faster.</p>
            </div>
            {isMobile && (
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-72 p-0 border-r border-border">
                  <SidebarContent />
                </SheetContent>
              </Sheet>
            )}
          </div>
        </header>

        <div className="flex-1 p-6">
          <div className="max-w-3xl mx-auto space-y-8">
            {/* Input Area */}
            <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
              <div className="space-y-4">
                <div className="relative flex flex-col gap-4">
                  {items.map((item, i) => (
                    <div key={i} className="relative flex items-center gap-3">
                      <div className="flex-1">
                        <Input
                          value={item}
                          onChange={(e) => handleItemChange(i, e.target.value)}
                          placeholder={`Item ${i + 1}`}
                          className="w-full text-lg h-12 bg-background border-border focus-visible:ring-primary"
                        />
                      </div>
                      {i === 2 && (
                        <Button variant="ghost" size="icon" onClick={() => removeItem(i)} className="text-muted-foreground hover:text-destructive">
                          <X className="w-5 h-5" />
                        </Button>
                      )}
                      
                      {i === 0 && items.length >= 2 && (
                        <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 z-10 hidden sm:block">
                          <Button variant="secondary" size="icon" className="w-8 h-8 rounded-full border border-border bg-card shadow-sm hover:text-primary hover:border-primary transition-colors" onClick={swapItems}>
                            <ArrowRightLeft className="w-4 h-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
                  <div>
                    {items.length < 3 && (
                      <Button variant="ghost" onClick={addItem} className="text-muted-foreground hover:text-primary">
                        <Plus className="w-4 h-4 mr-2" /> Add Item
                      </Button>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-3 w-full sm:w-auto">
                    <Button 
                      variant="outline" 
                      onClick={() => handleCompare("side-by-side")}
                      disabled={!canCompare || isStreaming}
                      className="flex-1 sm:flex-none border-border hover:bg-muted"
                    >
                      <LayoutPanelLeft className="w-4 h-4 mr-2" />
                      Side-by-Side
                    </Button>
                    <Button 
                      onClick={() => handleCompare("standard")}
                      disabled={!canCompare || isStreaming}
                      className="flex-1 sm:flex-none bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_15px_rgba(99,102,241,0.3)] hover:shadow-[0_0_20px_rgba(99,102,241,0.5)] transition-all"
                    >
                      <AlignLeft className="w-4 h-4 mr-2" />
                      Compare
                    </Button>
                  </div>
                </div>
              </div>

              {!result && !isStreaming && (
                <div className="mt-6 pt-6 border-t border-border">
                  <p className="text-xs text-muted-foreground mb-3 font-medium uppercase tracking-wider">Try comparing</p>
                  <div className="flex flex-wrap gap-2">
                    {["Mac vs Windows", "Gym vs Home Workout", "Python vs JavaScript", "Creatine vs Pre-Workout"].map((suggestion) => (
                      <button
                        key={suggestion}
                        onClick={() => applySuggestion(suggestion)}
                        className="px-3 py-1.5 rounded-full bg-muted/50 border border-border text-sm text-muted-foreground hover:text-foreground hover:border-primary/50 transition-colors"
                      >
                        {suggestion}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Results Area */}
            {(result || isStreaming || error) && (
              <div className="bg-card border border-border rounded-xl p-6 shadow-sm animate-in fade-in slide-in-from-bottom-4 duration-500">
                {error ? (
                  <div className="text-center py-8 space-y-4">
                    <div className="w-12 h-12 rounded-full bg-destructive/10 text-destructive flex items-center justify-center mx-auto">
                      <X className="w-6 h-6" />
                    </div>
                    <p className="text-destructive font-medium">{error}</p>
                    <Button variant="outline" onClick={() => handleCompare(mode)}>Try Again</Button>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between pb-4 border-b border-border">
                      <h3 className="text-xl font-bold text-foreground">
                        {items.filter(i => i.trim()).join(" vs ")}
                      </h3>
                      {!isStreaming && result && (
                        <Button variant="ghost" size="sm" onClick={() => setResult("")} className="text-muted-foreground">
                          Clear
                        </Button>
                      )}
                    </div>
                    
                    <div className="prose prose-invert max-w-none">
                      <MarkdownRenderer content={result} />
                    </div>

                    {isStreaming && (
                      <div className="space-y-4 py-4">
                        <Skeleton className="h-4 w-full bg-muted" />
                        <Skeleton className="h-4 w-5/6 bg-muted" />
                        <Skeleton className="h-4 w-4/6 bg-muted" />
                        <div className="flex items-center gap-1 mt-4 text-primary font-medium text-sm">
                          Thinking
                          <span className="flex gap-0.5 ml-1">
                            <span className="w-1 h-1 bg-primary rounded-full animate-bounce [animation-delay:-0.3s]" />
                            <span className="w-1 h-1 bg-primary rounded-full animate-bounce [animation-delay:-0.15s]" />
                            <span className="w-1 h-1 bg-primary rounded-full animate-bounce" />
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <footer className="py-8 text-center text-sm text-muted-foreground">
          Powered by AI
        </footer>
      </main>
    </div>
  );
}
