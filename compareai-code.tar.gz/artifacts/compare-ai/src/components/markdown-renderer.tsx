import React from "react";

export function MarkdownRenderer({ content }: { content: string }) {
  // A simple markdown renderer converting standard markdown to react nodes.
  
  // Clean up formatting
  const formattedContent = content
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/__(.*?)__/g, '<strong>$1</strong>')
    .replace(/_(.*?)_/g, '<em>$1</em>')
    .replace(/`([^`]+)`/g, '<code class="px-1 py-0.5 rounded bg-muted text-foreground text-sm">$1</code>')
    .replace(/^### (.*?)$/gm, '<h3 class="text-lg font-bold mt-6 mb-3 text-foreground">$1</h3>')
    .replace(/^## (.*?)$/gm, '<h2 class="text-xl font-bold mt-8 mb-4 text-primary">$1</h2>')
    .replace(/^# (.*?)$/gm, '<h1 class="text-2xl font-bold mt-8 mb-4 text-foreground">$1</h1>')
    .replace(/🏆/g, '<span class="text-xl">🏆</span>');

  // Parse blocks
  const blocks = formattedContent.split('\n\n');

  return (
    <div className="space-y-4 text-muted-foreground leading-relaxed">
      {blocks.map((block, i) => {
        // Table parsing
        if (block.startsWith('|') && block.includes('|-')) {
          const rows = block.split('\n').filter(r => r.trim());
          const headers = rows[0].split('|').filter(Boolean).map(h => h.trim());
          const dataRows = rows.slice(2).map(r => r.split('|').filter(Boolean).map(c => c.trim()));
          
          return (
            <div key={i} className="overflow-x-auto w-full my-6 rounded-lg border border-border">
              <table className="w-full text-left border-collapse text-sm">
                <thead className="bg-muted">
                  <tr>
                    {headers.map((h, j) => (
                      <th key={j} className="p-3 font-medium text-foreground border-b border-border" dangerouslySetInnerHTML={{ __html: h }} />
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {dataRows.map((row, j) => (
                    <tr key={j} className="hover:bg-muted/50 transition-colors">
                      {row.map((cell, k) => (
                        <td key={k} className="p-3 text-muted-foreground" dangerouslySetInnerHTML={{ __html: cell }} />
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          );
        }

        // List parsing
        if (block.match(/^(-|\*) /m)) {
          const listItems = block.split('\n').filter(Boolean);
          return (
            <ul key={i} className="space-y-2 my-4">
              {listItems.map((item, j) => {
                const text = item.replace(/^(-|\*) /, '');
                // Styling pros and cons specifically if detected
                const isPro = text.toLowerCase().includes('pro:') || text.toLowerCase().includes('advantage:');
                const isCon = text.toLowerCase().includes('con:') || text.toLowerCase().includes('disadvantage:');
                
                return (
                  <li key={j} className="flex items-start gap-2">
                    <span className={`mt-1.5 flex-shrink-0 w-1.5 h-1.5 rounded-full ${isPro ? 'bg-green-500' : isCon ? 'bg-red-500' : 'bg-primary'}`} />
                    <span dangerouslySetInnerHTML={{ __html: text }} />
                  </li>
                );
              })}
            </ul>
          );
        }

        // Overall Winner Card
        if (block.toLowerCase().includes('overall winner') || block.includes('🏆')) {
          return (
            <div key={i} className="my-8 p-6 rounded-xl border border-primary/30 bg-primary/5 shadow-[0_0_15px_rgba(99,102,241,0.15)] relative overflow-hidden">
              <div className="absolute top-0 left-0 w-1 h-full bg-primary" />
              <div dangerouslySetInnerHTML={{ __html: block }} className="text-foreground font-medium" />
            </div>
          );
        }

        // Regular paragraph
        if (block.trim()) {
          return <p key={i} dangerouslySetInnerHTML={{ __html: block }} />;
        }
        
        return null;
      })}
    </div>
  );
}
